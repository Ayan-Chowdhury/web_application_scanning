from core.result import ScanResult

def analyze(target_url, response, client):
    results = []
    base = target_url.rstrip("/")

    for path in ["robots.txt", "sitemap.xml"]:
        url = f"{base}/{path}"
        r = client.get(url, allow_redirects=False)
        if not r or r.status_code != 200:
            continue

        content_type = r.headers.get("Content-Type", "").lower()
        body = r.text.strip().lower()

        # Reject HTML custom error/login pages returned with HTTP 200
        if "text/html" in content_type or "<!doctype html" in body or "<html" in body:
            continue

        if len(body) > 0:
            results.append(
                ScanResult(
                    target_url=url,
                    vulnerability=f"{path} Found",
                    severity="Info",
                    confidence=0.95,
                    description=f"{path} is accessible and may disclose internal paths.",
                    recommendation="Review the file contents and ensure no sensitive paths are exposed.",
                    evidence=f"Accessible: {url}"
                )
            )

    return results